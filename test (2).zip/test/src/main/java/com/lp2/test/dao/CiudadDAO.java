
package com.lp2.test.dao;

import com.lp2.test.modelo.Ciudad;
import com.lp2.test.modelo.Ciudadano;
import java.util.List;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

/**
 *
 * @author Estefanie
 */

@RepositoryRestResource(path = "ciudades", collectionResourceRel = "ciudades")
public interface CiudadDAO extends CrudRepository<Ciudad, Long>{
    @Override
    public List<Ciudad> findAll();
}
